# Class structure

## Constants
1. public constants (public static final)
2. protected constants (protected static final)
3. private constants (private static final)

## Fields
4. public fields
5. protected fields
6. private fields

## Constructors
7. public constructors
8. protected constructors
9. private constructors

## Methods
10. public static methods
11. public methods
12. protected static methods
13. protected methods
14. private static methods
15. private methods

## Internal classes
16. public static classes
17. public classes
18. protected static classes
19. protected classes
20. private static classes
21. private classes
